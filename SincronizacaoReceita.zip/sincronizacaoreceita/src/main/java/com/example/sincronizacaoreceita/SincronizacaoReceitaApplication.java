package com.example.sincronizacaoreceita;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.sincronizacaoreceita.conta.Conta;
import com.example.sincronizacaoreceita.service.ReceitaService;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

@SpringBootApplication
public class SincronizacaoReceitaApplication {

	public static void main(String[] args) throws RuntimeException, InterruptedException {
		ArrayList<Conta> contasExibir = new ArrayList<>();
		contasExibir = LerArquivo ();
		boolean validacaoConta = false;
		// Exemplo como chamar o "serviço" do Banco Central.
        ReceitaService receitaService = new ReceitaService();
        
		for (Conta contaExibir : contasExibir) {
			System.out.print("Agencia : " + contaExibir.getAgencia());
	    	System.out.print(" Conta : " + contaExibir.getConta());
	    	System.out.print(" Saldo : " + contaExibir.getSaldo());
	    	System.out.print(" status : " + contaExibir.getStatus());
	    	//System.out.println("");
	        validacaoConta = receitaService.atualizarConta(
	        		contaExibir.getAgencia(),
	        		contaExibir.getConta(),
	        		Double.parseDouble(contaExibir.getSaldo()),
	        		contaExibir.getStatus());
	        
	        contaExibir.setValidacao(validacaoConta);
	        
	        System.out.print(" Validação : " + contaExibir.getValidacao());
	        System.out.println("");
		}
		
		gravarCSV(contasExibir);
		
	}

	public static ArrayList<Conta> LerArquivo () {
		String arquivoCSV = "C:\\SincronizacaoReceita\\in\\contas.csv";
		Reader reader = null;
		String csvDivisor = ";";
		ArrayList<Conta> contas = new ArrayList<>();
		try {
			reader = Files.newBufferedReader(Paths.get(arquivoCSV));
			CSVReader csvReader = new CSVReaderBuilder(reader).withSkipLines(1).build();
	        List<String[]> linhas = csvReader.readAll();
	        System.out.println("lendo arquivo...");
	        for (String[] linha : linhas) {
	        	String[] coluna = linha[0].split(csvDivisor);
	        	
	        	Conta conta = new Conta(coluna[0],
	        							coluna[1],
	        							coluna[2].replaceAll(",", "."),
	        							coluna[3],
	        							true);
	        	contas.add(conta);
	        }
	        
	        	
		} catch (IOException e) {
			e.printStackTrace();
		}
		return contas;
	}
	
	private static void gravarCSV(ArrayList<Conta> contas) {
		String arquivoCSV = "C:\\SincronizacaoReceita\\out\\contasOut.csv";
		Writer writer;
		String[] cabecalho = {"agencia", "conta", "saldo", "status", "validacao"};
		List<String[]> linhas = new ArrayList<>();
		try {
			writer = Files.newBufferedWriter(Paths.get(arquivoCSV));
			CSVWriter csvWriter = new CSVWriter(writer);
			for (Conta conta : contas) {
				linhas.add(new String[]{
						conta.getAgencia(),
						conta.getConta(),
						conta.getSaldo().replace(".", ","),
						conta.getStatus(),
						Boolean.toString(conta.getValidacao())
				});
			}
			System.out.println("Gravando arquivo...");
			csvWriter.writeNext(cabecalho);
			csvWriter.writeAll(linhas);
			writer.flush();
	        writer.close();	        
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Fim...");
	}
}
