package com.example.sincronizacaoreceita.conta;

public class Conta {
	
	private String agencia;
	private String conta;
	private String saldo;
	private String status;
	private boolean validacao;
	
	public Conta(String agencia, String conta, String saldo, String status, boolean validacao) {
		super();
		this.agencia = agencia;
		this.conta = conta;
		this.saldo = saldo;
		this.status = status;
		this.validacao = validacao;
	}
	public Conta() {
		super();
	}
	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getSaldo() {
		return saldo;
	}

	public void setSaldo(String saldo) {
		this.saldo = saldo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public boolean getValidacao() {
		return validacao;
	}
	public void setValidacao(boolean validacao) {
		this.validacao = validacao;
	}
	
}
